local MODULE = MODULE

-- MODULE.config.AddTheme('clonePhaseII', 'Clone Wars Phase II Style', {
--     ['surrender'] = Material('mvp/perfecthands/themes/clone2/surrender.png', 'mips smooth'),
--     ['armsinfront'] = Material('mvp/perfecthands/themes/clone2/infront.png', 'mips smooth'),
--     ['armsbehind'] = Material('mvp/perfecthands/themes/clone2/back.png', 'mips smooth'),
--     ['comlink'] = Material('mvp/perfecthands/themes/clone2/comlink.png', 'mips smooth'),
--     ['highfive'] = Material('mvp/perfecthands/themes/clone2/highfive.png', 'mips smooth'),
--     ['hololink'] = Material('mvp/perfecthands/themes/clone2/hololink.png', 'mips smooth'),
--     ['point'] = Material('mvp/perfecthands/themes/clone2/point.png', 'mips smooth'),
--     ['salute'] = Material('mvp/perfecthands/themes/clone2/salute.png', 'mips smooth'),
--     ['armsbehindhead'] = Material('mvp/perfecthands/themes/clone2/armsbehindhad.png', 'mips smooth'),
--     ['armsonbelt'] = Material('mvp/perfecthands/themes/clone2/armsonbelt.png', 'mips smooth'),
--     ['pensive'] = Material('mvp/perfecthands/themes/clone2/pensive.png', 'mips smooth'),
--     ['typing'] = Material('mvp/perfecthands/themes/clone2/typing.png', 'mips smooth')
-- })

-- MODULE.config.AddTheme('clonePhaseI', 'Clone Wars Phase I Style', {
--     ['surrender'] = Material('mvp/perfecthands/themes/clone2/surrender.png', 'mips smooth'),
--     ['armsinfront'] = Material('mvp/perfecthands/themes/clone2/infront.png', 'mips smooth'),
--     ['armsbehind'] = Material('mvp/perfecthands/themes/clone2/back.png', 'mips smooth'),
--     ['comlink'] = Material('mvp/perfecthands/themes/clone2/comlink.png', 'mips smooth'),
--     ['highfive'] = Material('mvp/perfecthands/themes/clone2/highfive.png', 'mips smooth'),
--     ['hololink'] = Material('mvp/perfecthands/themes/clone2/hololink.png', 'mips smooth'),
--     ['point'] = Material('mvp/perfecthands/themes/clone2/point.png', 'mips smooth'),
--     ['salute'] = Material('mvp/perfecthands/themes/clone2/salute.png', 'mips smooth'),
--     ['armsbehindhead'] = Material('mvp/perfecthands/themes/clone2/armsbehindhad.png', 'mips smooth'),
--     ['armsonbelt'] = Material('mvp/perfecthands/themes/clone2/armsonbelt.png', 'mips smooth'),
--     ['pensive'] = Material('mvp/perfecthands/themes/clone2/pensive.png', 'mips smooth'),
--     ['typing'] = Material('mvp/perfecthands/themes/clone2/typing.png', 'mips smooth')
-- })

-- MODULE.config.AddTheme('imperial', 'Imperial Style', {
--     ['surrender'] = Material('mvp/perfecthands/themes/imp/surrender.png', 'mips smooth'),
--     ['armsinfront'] = Material('mvp/perfecthands/themes/imp/infront.png', 'mips smooth'),
--     ['armsbehind'] = Material('mvp/perfecthands/themes/imp/back.png', 'mips smooth'),
--     ['comlink'] = Material('mvp/perfecthands/themes/imp/comlink.png', 'mips smooth'),
--     ['highfive'] = Material('mvp/perfecthands/themes/imp/highfive.png', 'mips smooth'),
--     ['hololink'] = Material('mvp/perfecthands/themes/imp/hololink.png', 'mips smooth'),
--     ['point'] = Material('mvp/perfecthands/themes/imp/point.png', 'mips smooth'),
--     ['salute'] = Material('mvp/perfecthands/themes/imp/salute.png', 'mips smooth'),
--     ['armsbehindhead'] = Material('mvp/perfecthands/themes/imp/armsbehindhad.png', 'mips smooth'),
--     ['armsonbelt'] = Material('mvp/perfecthands/themes/imp/armsonbelt.png', 'mips smooth'),
--     ['pensive'] = Material('mvp/perfecthands/themes/imp/pensive.png', 'mips smooth'),
--     ['typing'] = Material('mvp/perfecthands/themes/imp/typing.png', 'mips smooth')
-- })

hook.Run('mvp.AddCustomThemes', MODULE)